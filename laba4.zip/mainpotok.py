import tkinter as tk
import threading
import time
from second_thread import SecondThread

class MainApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("Two Threads Example")

        self.label1 = tk.Label(root, text="Thread 1:")
        self.label1.pack()

        self.label2 = tk.Label(root, text="Thread 2:")
        self.label2.pack()

        self.start_stop_button = tk.Button(root, text="Start", command=self.toggle_threads)
        self.start_stop_button.pack()

        # Создаем второй поток
        self.second_thread = SecondThread(self)

        # Флаг для указания состояния потоков
        self.threads_running = False

    def toggle_threads(self):
        # Если потоки работают, останавливаем их, и меняем текст кнопки
        if self.threads_running:
            self.stop_threads()
            self.start_stop_button.config(text="Start")
        # Если потоки не работают, запускаем их, и меняем текст кнопки
        else:
            self.start_threads()
            self.start_stop_button.config(text="Stop")

    def start_threads(self):
        self.threads_running = True
        self.second_thread.start()
        threading.Thread(target=self.run_thread1).start()

    def stop_threads(self):
        self.threads_running = False
        self.second_thread.stop()

    def run_thread1(self):
        counter = 0
        while self.threads_running:
            self.label1.config(text=f"Thread 1: Counter {counter}")
            counter += 1
            time.sleep(1)

def main():
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()

if __name__ == "__main__":
    main()
