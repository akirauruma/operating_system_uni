import threading
import time

class SecondThread(threading.Thread):
    def __init__(self, main_app):
        super().__init__()
        self.main_app = main_app
        self.running = True

    def run(self):
        counter = 0
        while self.running:
            self.main_app.label2.config(text=f"Thread 2: Counter {counter}")
            counter += 1
            time.sleep(1)

    def stop(self):
        self.running = False
